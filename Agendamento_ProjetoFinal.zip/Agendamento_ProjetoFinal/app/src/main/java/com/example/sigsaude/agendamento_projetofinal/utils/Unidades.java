package com.example.sigsaude.agendamento_projetofinal.utils;

public enum Unidades {
    SEPA,
    Departamento_de_Odontologia,
    DAS,
    Departamento_de_nutrição
}
